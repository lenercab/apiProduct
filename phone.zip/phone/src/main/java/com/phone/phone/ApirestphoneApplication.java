package com.phone.phone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApirestphoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApirestphoneApplication.class, args);
	}

}
