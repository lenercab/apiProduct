package com.address.apirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApirestaddressApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApirestaddressApplication.class, args);
	}

}
